package com.matiasmandelbaum.alejandriaapp.data.util

object FirebaseConstants {
    const val BOOKS_COLLECTION = "libros"

}