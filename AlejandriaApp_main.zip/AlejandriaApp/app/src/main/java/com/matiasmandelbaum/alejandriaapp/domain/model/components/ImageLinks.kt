package com.matiasmandelbaum.alejandriaapp.domain.model.components

data class ImageLinks(
    val smallThumbnail: String?
)