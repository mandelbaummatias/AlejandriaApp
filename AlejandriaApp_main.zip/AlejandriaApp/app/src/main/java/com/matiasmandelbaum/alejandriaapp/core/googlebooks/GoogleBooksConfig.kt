package com.matiasmandelbaum.alejandriaapp.core.googlebooks

object GoogleBooksConfig {
    lateinit var apiKey: String
    lateinit var baseUrl: String
}
